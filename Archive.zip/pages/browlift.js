import Breast from "../Components/Breast";
import { BrowLift } from "../Components/BrowLift";
import Headfoot from "../helpers/Headfoot";
export default function MyIndexPage() {
  return (
    <Headfoot>
      <BrowLift />
    </Headfoot>
  )
}
