import { Footer } from "../Components/Footer";
import { Header } from "../Components/Header";
import Home from "../Components/Home";
import Headfoot from "../helpers/Headfoot";

export default function MyIndexPage() {

  return (
    <Headfoot>
      <Home />
    </Headfoot>
  )
}
