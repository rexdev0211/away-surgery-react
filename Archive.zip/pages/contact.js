import { ContactUs } from "../Components/Contact";
import Headfoot from "../helpers/Headfoot";

export default function MyIndexPage() {
  return (
    <Headfoot>
      <ContactUs />
    </Headfoot>
  )
}
