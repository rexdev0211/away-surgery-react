import Hair from "../Components/Hair";
import Headfoot from "../helpers/Headfoot";

export default function HairPage() {
  return (
    <Headfoot>
      <Hair />
    </Headfoot >
  )
}
