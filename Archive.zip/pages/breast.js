import { Footer } from "../Components/Footer";
import { Header } from "../Components/Header";
import Breast from "../Components/Breast";
import Headfoot from "../helpers/Headfoot";
export default function MyIndexPage() {
  return (
    <Headfoot>
      <Breast />
    </Headfoot>
  )
}
