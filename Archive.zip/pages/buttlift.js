
import { ButtLift } from "../Components/Buttlift";
import Headfoot from "../helpers/Headfoot";
export default function ButtLiftPage() {
  return (
    <Headfoot>
      <ButtLift />
    </Headfoot>
  )
}
